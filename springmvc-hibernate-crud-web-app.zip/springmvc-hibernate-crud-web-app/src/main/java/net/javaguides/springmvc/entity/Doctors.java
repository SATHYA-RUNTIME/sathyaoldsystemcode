import javax.persistence.Entity;


@Entity
public class Doctors {

    private String a;
    private int password;
    @id
    private int D_ID;
    private String D_NAME;
    private int APP_ID;
 
}   
