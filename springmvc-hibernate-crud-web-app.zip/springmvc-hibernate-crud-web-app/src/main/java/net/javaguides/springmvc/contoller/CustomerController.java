package net.javaguides.springmvc.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession; 
import net.javaguides.springmvc.dao.CustomerDAO;
import net.javaguides.springmvc.entity.Customer;
import net.javaguides.springmvc.entity.Patient;
import net.javaguides.springmvc.service.CustomerService;
import org.springframework.ui.ModelMap;

@Controller
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;
    @Autowired
    private CustomerDAO customerDAO;

    @GetMapping("/showdoctor")
    public void show(HttpServletRequest request, HttpServletResponse response){
        // Patient patient=new Patient();
        // // System.out.println("---->"+patient);
        // HttpSession session1 = request.getSession();
        // System.out.println(session1.getAttribute("MySessionVariable"));
   
    }
    @RequestMapping("/")
    public String moveon(){
        return "index";
        
    }
    @PostMapping("/check")
    public String listCustomers(@RequestParam("un") String uname,@RequestParam("ps") String pw,HttpServletRequest request, HttpServletResponse response,ModelMap model) {    
       System.out.println("username:"+uname);
       System.out.println("password:"+pw);
       
       System.out.println(customerDAO.login(uname,pw));
       if (customerDAO.login(uname,pw)) {
        System.out.println("working fine");
        HttpSession session1 = request.getSession();
session1.setAttribute("MySessionVariable", uname);
        // ModelMap model=new ModelMap();
        // ModelAndView mav = new ModelAndView("doctor"); 
        // mav.addObject("uname1","gkghgy");
        // model.addAttribute("uname1",request.getAttribute("MySessionVariable"));
        model.addAttribute("uname1", session1.getAttribute("MySessionVariable"));

        return "doctor";
       } else {
        System.out.println("working bad");
        return "error";
       }
        
    }

    @GetMapping("/list")
    public String listCustomers(Model theModel) {
        List < Customer > theCustomers = customerService.getCustomers();
        theModel.addAttribute("customers", theCustomers);
        return "list-customers";
    }

    @GetMapping("/showForm")
    public String showFormForAdd(Model theModel) {
        Customer theCustomer = new Customer();
        theModel.addAttribute("customer", theCustomer);
        return "customer-form";
    }

    @PostMapping("/saveCustomer")
    public String saveCustomer(@ModelAttribute("customer") Customer theCustomer) {
        customerService.saveCustomer(theCustomer);
        return "redirect:/customer/list";
    }

    @GetMapping("/updateForm")
    public String showFormForUpdate(@RequestParam("customerId") int theId,
        Model theModel) {
        Customer theCustomer = customerService.getCustomer(theId);
        theModel.addAttribute("customer", theCustomer);
        return "customer-form";
    }

    @GetMapping("/delete")
    public String deleteCustomer(@RequestParam("customerId") int theId) {
        customerService.deleteCustomer(theId);
        return "redirect:/customer/list";
    }
}
