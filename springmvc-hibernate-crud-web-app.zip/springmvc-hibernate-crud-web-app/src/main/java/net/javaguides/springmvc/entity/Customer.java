class{
    main
}